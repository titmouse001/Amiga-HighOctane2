//E:\amiga\dh1\hoII_1\hoII\data\gfx\Bitmaps\BLOCKS01.bmp
//Converti avec GBA Graphics par Br�nni
//Palette
//Taille: 16
//M�moire: 32 octets

const unsigned short BLOCKS01_palette[16]=	{
0x0000, 0x1800, 0x0100, 0x4084, 0x1184, 0x18c6, 0x0108, 0x6108,
0x2208, 0x294a, 0x000e, 0x5294, 0x1216, 0x001a, 0x22de, 0x6bde};
