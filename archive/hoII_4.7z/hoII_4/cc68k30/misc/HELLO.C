/*  HELLO.C  -  Het eerste C programma
 *  Compileren met 'CC HELLO' of 'CC HELLO -M'
 *  Uitvoeren met 'SIM68K'
 *  Direct uitvoeren met 'CCG HELLO'
 *
 *  P.J.Fondse  10-12-1995
 */

#include <stdio.h>

main()
{
    printf("Hello, world!\n");
}
