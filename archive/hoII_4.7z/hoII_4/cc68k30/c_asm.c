char	GlobalData[32];

void
main(void)
{
	static char	staticfuncdata[32];
	char	tempfuncdata[32];
	
	staticfuncdata[0] = tempfuncdata[0];
}